﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CookiesExample.Models
{
    public class DummyData
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
